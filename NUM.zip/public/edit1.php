<?php

$ip=$_POST['ip'];
$username=$_POST['username'];
$password=$_POST['password'];
$card=$_POST['card'];
require_once('api.php');
$API=new RouterosAPI();
$API->connect($ip,$username,$password) or die("disconected");
//echo "<pre>";
//print_r($edit);
$test=$_POST['test'];
$profile=$_POST['profile'];
$disable=$_POST['disable'];
$einable=$_POST['einable'];
$reset=$_POST['reset'];
$shew="";
$user=$API->comm("/tool/user-manager/user/print",array());
for($i=0;$i<count($user);$i++){
    
    if($user[$i]['username']==$card)
    {
        $numbers=$i;
        
    }
    
}
if($test=="profile")
{
$add2=$API->comm("/tool/user-manager/user/create-and-activate-profile",array(
        
        "customer"=>$username,
        "profile"=>$profile,
        "numbers"=>$numbers
        
        
        
        ));
        
    $shew="تم تغيير باقة.." ;

}else if($test=="disable"){
    
$add2=$API->comm("/tool/user-manager/user/disable",array(
        
    
        "numbers"=>$numbers
        
        
        
        ));
  $shew="تم تعطيل ";
    
}else if($test=="einable"){
    
    
$add2=$API->comm("/tool/user-manager/user/enable",array(
        
        "numbers"=>$numbers
        
        
        
        ));
    
$shew="تم تفعيل  ";
    
}else if($test=="reset"){
    
$add2=$API->comm("/tool/user-manager/user/reset-counters",array(
        
    
        "numbers"=>$numbers
        
        
        
        ));
    
    $shew="تم تصفير عدادات ..";
    
}else if($test=="remove"){
    
$add2=$API->comm("/tool/user-manager/user/remove",array(
        
        
        "numbers"=>$numbers
        
        
        
        ));
    
    $shew="تم حذف  ..";
    
}



?>


<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
        		<meta charset="utf-8">
		
    <meta keywords="htmls, learn, teach"/>

    <link rel="stylesheet" type="text/css" href="style.css">
  
<link rel="icon" href="icon.s" />
    <title>تمت العمليه بنجاح</title>
  
</head>
<body>

<hr>
<img class="logo" src="logo.s" width="100%">
<hr>
<center>
<fieldset>
<?


echo $shew."<br><br>";
echo "هذا الكرت : ".$card." بنجاح";
echo "<br><br>";

?>

</fieldset>





</center>






</body>



</html>