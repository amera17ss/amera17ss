<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
        		<meta charset="utf-8">
		
    <meta keywords="htmls, learn, teach"/>

    <link rel="stylesheet" type="text/css" href="style.css">
  
<link rel="icon" href="icon.s" />
    <title>المبيعات</title>
  
</head>
<body>

<hr>
<img class="logo" src="logo.s" width="100%">
<hr>

<center>
<fieldset>
<?php


$ip=$_REQUEST['ip'];
$username=$_REQUEST['username'];
$password=$_REQUEST['password'];
echo $ip;



require_once('api.php');
$API = new RouterosAPI();
@$API->connect($ip,$username,$password) or die("desconcted");
    //echo " <br/>concted<br/>";
    
    
    
    $price1=$API->comm("/tool/user-manager/payment/print",array(
        ));

    $enduser=$API->comm("/tool/user-manager/user/print",array(
        ));

 $session=$API->comm("/tool/user-manager/session/print",array());
//echo "<pre>";

//print_r($session);
   


?>
    <table cellspacing="0" border="1"
    >
        
        <tr>
            <th>منفذ دخول الكرت</th>
            
            <th>
                السعر
            </th>
            <th>
            التاريخ
            </th>
            <th>الكرت</th>
            
            
        </tr>
        
    
<?php



    

$b=0;
$s=0;

$se=0;
$tim=array();
$card=array();
$price=array();

/******تخزين الكروت المستخدم
ه*******/
for($n=0;$n<count($enduser);$n++){
    if($enduser[$n]['last-seen']=="never"){
        
    $s++;

    }
    else{
          //$card[$b]['date']=substr($enduser[$n]['last-seen'],0,11);
  $card[$b]['user']=$enduser[$n]['username'];

        
 $b++;
    };
  




};
//$st="najeeb murad";
//echo substr($tim[1],0,11);

//echo "<pre>";
//print_r($card);
/*******  تخزين التاريخ في المصفوفه *******/

for($n=count($session)-1;$n>=0;$n--)
{
for($size=0;$size<count($card);$size++){
    
    
if($session[$n]['user']==$card[$size]['user'])
{
    
    $card[$size]['date']=substr($session[$n]['from-time'],0,11);
$card[$size]['out']=$session[$n]['nas-port-id'];
    
}
}



};





$m=0;
/***تخزين السعر في المصفوفه ***/
for($n=0;$n<count($price1);$n++)
{
for($size=0;$size<count($card);$size++){
    
    
if($price1[$n]['user']==$card[$size]['user'])
{
    
    $card[$size]['price']=$price1[$n]['price']/100;
    
}
}



};

//echo $m;

//echo "<pre>";
//print_r($card);
/******************/

//بحث عن الكروت عبر التاريخ
$sum=0;
$c=0;
$tmp=$_REQUEST['tmp'];
@$day1=$_REQUEST['day1'];
@$day2=$_REQUEST['day2'];
@$years=$_POST['years'];
@$month=$_REQUEST['month'];
echo "<br>";

for($n=0;$n<count($card);$n++)
{
    
    

   if($tmp=="f") 
   {
       
       @ $date=$_REQUEST['date'];;
if(@$card[$n]['date']==@$date)

        {
@$sum+=$card[$n]['price'];
$c++;
//echo $card[$n]['price'] . "<br/>";
//echo $card[$n]['user'] . "<br/>";
//echo $card[$n]['date'] . "<br/>";

echo "<tr>";
echo "<td>" .$card[$n]['out'] . "</td>";
echo "<td>".$card[$n]['price'] . " ريال</td>";
echo "<td>". $card[$n]['date'] . "</td>";
echo "<td>" .$card[$n]['user'] . "</td>";
echo "</tr>";
}
       
   }else{
for($i=$day1;$i<=$day2;$i++)
{

    if($i<10){
   @ $date=$month."/0".$i."/".$years;
if(@$card[$n]['date']==@$date)

        {
@$sum+=$card[$n]['price'];
$c++;
//echo $card[$n]['price'] . "<br/>";
//echo $card[$n]['user'] . "<br/>";
//echo $card[$n]['date'] . "<br/>";

echo "<tr>";
echo "<td>" .$card[$n]['out'] . "</td>";
echo "<td>".$card[$n]['price'] . " ريال</td>";
echo "<td>". $card[$n]['date'] . "</td>";
echo "<td>" .$card[$n]['user'] . "</td>";
echo "</tr>";

        }
}else{
       @ $date=$month."/".$i."/".$years;
if(@$card[$n]['date']==@$date)

        {
@$sum+=$card[$n]['price'];
$c++;
//echo $card[$n]['price'] . "<br/>";
//echo $card[$n]['user'] . "<br/>";
//echo $card[$n]['date'] . "<br/>";

echo "<tr>";
echo "<td>" .$card[$n]['out'] . "</td>";
echo "<td>".$card[$n]['price'] . " ريال</td>";
echo "<td>". $card[$n]['date'] . "</td>";
echo "<td>" .$card[$n]['user'] . "</td>";

echo "</tr>";


        }
    
}
    
} 
}
};
/****************/
//echo "<br/>";
echo "  اجمالي المبلغ : ";
echo $sum;
echo " ريال "." - ";
echo "  عدد الكروت : ";
echo  $c;

echo "<br><hr>";
//-201950;
//echo $price;
//echo "<br/>================<br/>";
//echo "<br>";
//echo $s ." : غير مستخدم";
//echo "<br/>================";
//echo "<br>";
//echo $b . " : الكروت المستخدمه"
;
//echo "<br/>";
//echo $se;


/**********/







?>
        
    </table>


</fieldset>





</center>






</body>



</html>