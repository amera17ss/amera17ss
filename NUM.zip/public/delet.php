<?php

$ip=$_POST['ip'];
$username=$_POST['username'];
$password=$_POST['password'];
require_once("api.php");
$API=new RouterosAPI();
$API->connect($ip,$username,$password);

$user=$API->comm("/tool/user-manager/user/print",array());



$r=0;
$endusers=array();
for($i=0;$i<count($user);$i++){

  
 if(@$user[$i]['actual-profile']=="")
 {
     $endusers[$r]['user']=$user[$i]['username'];
@$endusers[$r]['download']=number_format(($user[$i]['download-used']+$user[$i]['upload-used'])/1024/1024);
@$endusers[$r]['tim']=$user[$i]['uptime-used'];
@$endusers[$r]['numbers']=$i;
     $r++;
     
 }else{
     
     
     
 }
      
      
  
    
    
}

//echo $r;
//echo "<pre>";
//print_r($endusers);
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
        		<meta charset="utf-8">
		
    <meta keywords="htmls, learn, teach"/>

    <link rel="stylesheet" type="text/css" href="style.css">
  
<link rel="icon" href="icon.s" />
    <title>صفحة الكروت المنتهيه</title>
  
</head>
<body>

<hr>
<img class="logo" src="logo.s" width="100%">
<hr>
<center>
   
<fieldset>
    <form action="delet1.php" method="POST">
        
  
       <input type="hidden" name="test"
value="remove"/>

       <input type="hidden" name="ip"
value="<?php echo $_POST['ip'];?>"/>
<input type="hidden" name="username" value="<?php echo $_POST['username'];?>"/>
<input type="hidden" name="password" value="<?php echo $_POST['password'];?>"/>
<br>

    
 <input onclick="return getConfirmation();"   type="submit" value="حذف الكروت المنتهيه "class="submit"/>
    </form>
    <br>
    
 عدد الكروت المنتهيه :
    <?echo $r;?> 
    <hr>
    
   <table class="usersend">
        
        <tr class="tr1">
            <th>تعديل</th>
            <th>الوقت</th>
            
            <th>التحميل</th>
            <th>الكرت</th>
            
            
        </tr>
        <?
for($i=0;$i<count($endusers);$i++){
    
$card=$endusers[$i]['user'];
    
    
    ?>
    <tr class="tr2">

<td> <form  action="edit.php" method="POST">
      
      
       <input type="hidden" name="ip"
value="<?php echo $_POST['ip'];?>"/>
<input type="hidden" name="username" value="<?php echo $_POST['username'];?>"/>
<input type="hidden" name="password" value="<?php echo $_POST['password'];?>"/>

<input type="hidden" name="password" value="<?php echo $_POST['password'];?>"/>

<input type="hidden" name="card" value="<?php echo $card ;?>"/>
      <input class="userman" type="submit"value="تعديل">
      
      
      
  </form></td>



    
   <td><?echo $endusers[$i]['tim'] ?></td>
  <td><?echo $endusers[$i]['download']."MB"; ?></td>
    <td><?echo $endusers[$i]['user'] ?></td>
    
</tr>
    
    <?
    
    
}
        ?>
        
        
        
    </table>
    
    

</fieldset>





</center>


<script>
function getConfirmation(){
    
    var A=confirm("هل انت متأكد من حذف الكروت المنتهيه ، حذف الكروت المنتهيه يؤثر على صحة بيانات المبيعات؟");
    
if(A==true)
    {
        
        return true;
    }else{
        
        return false;
    }
}

    
</script>



</body>



</html>