<?php

@$ip=$_POST['ip'];
@$username=$_POST['username'];
@$password=$_POST['password'];
@$test=$_POST['test'];
require_once('api.php');
$API=new RouterosAPI();
$API->connect($ip,$username,$password) or die("disconected");
$user=$API->comm("/tool/user-manager/user/print",array());
$endusers=array();
$r=0;
for($i=0;$i<count($user);$i++){

  
 if(@$user[$i]['actual-profile']=="")
 {
     $endusers[$r]['user']=$i;
     $r++;
     
 }
    
}
  

if($test=="remove"){
    
//echo "<pre>";
//print_r($endusers);
for($i=0;$i<count($endusers);$i++){
    
    
    
$add2=$API->comm("/tool/user-manager/user/remove",array(
        
    
        "numbers"=>$endusers[$i]['user']
        
        
        
        ));
    
}



$mas=" تم حذف الكروت المنتهيه بنجاح ";
    
}else{
    
    
    
}


?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
        		<meta charset="utf-8">
		
    <meta keywords="htmls, learn, teach"/>

    <link rel="stylesheet" type="text/css" href="style.css">
  
<link rel="icon" href="icon.s" />
    <title>تم حذف الكروت المنتهيه</title>
  
</head>
<body>

<hr>
<img class="logo" src="logo.s" width="100%">
<hr>
<center>
<fieldset>
    <br>
<?

echo $mas;

?>
<br><br>
</fieldset>





</center>






</body>



</html>