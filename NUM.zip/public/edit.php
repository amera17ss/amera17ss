<?php

$ip=$_POST['ip'];
$username=$_POST['username'];
$password=$_POST['password'];
$card=$_POST['card'];
require_once('api.php');
$API=new RouterosAPI();
$API->connect($ip,$username,$password) or die("disconected");
$profile=$API->comm("/tool/user-manager/profile/print",array( ));
//echo "<pre>";
//print_r($profile);
$user=$API->comm("/tool/user-manager/user/print",array( ));

?>



<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
        		<meta charset="utf-8">
		
    <meta keywords="htmls, learn, teach"/>

    <link rel="stylesheet" type="text/css" href="style.css">
  
<link rel="icon" href="icon.s" />
    <title>تعديل الكرت</title>
  
</head>
<body dir="rtl">
    

<hr>
<img class="logo" src="logo.s" width="100%">
<hr>
<center>
<fieldset>

    <hr>
    <form action="edit1.php" method="POST">
        
  
      تغيير الباقه : 
        
        <select name="profile">
            
           <?php
    for($i=0;$i<count($profile);$i++)
           {
               
echo "<option value='".$profile[$i]['name']."'>".$profile[$i]['name']."</option>";
           }
           
           
           ?> 
           
            
        </select>
        
  <input type="hidden" name="ip"
value="<?php echo $_POST['ip'];?>"/>
<input type="hidden" name="username" value="<?php echo $_POST['username'];?>"/>
<input type="hidden" name="password" value="<?php echo $_POST['password'];?>"/>

<input type="hidden" name="password" value="<?php echo $_POST['password'];?>"/>

<input type="hidden" name="test" value="profile"/>

<input type="hidden" name="card" value="<?php echo $card ;?>"/>
<br><br>
 <input class="edit" onclick="return getConfirmation();" type="submit" value="تغيير الباقه" name="sub"/>
        
        </form>
        <br>


 <form action="edit1.php" method="POST">
        
  <?
  
  for($i=0;$i<count($user);$i++)
  {
      
if($user[$i]['username']==$card)
{
    
    if($user[$i]['disabled']=="false")
    {
        
         ?>
         
           <input type="hidden" name="ip"
value="<?php echo $_POST['ip'];?>"/>
<input type="hidden" name="username" value="<?php echo $_POST['username'];?>"/>
<input type="hidden" name="password" value="<?php echo $_POST['password'];?>"/>

<input type="hidden" name="password" value="<?php echo $_POST['password'];?>"/>



<input type="hidden" name="test" value="disable"/>

<input type="hidden" name="card" value="<?php echo $card ;?>"/>
 <input class="edit" onclick="return getConfirmation();" type="submit" value="تعطيل" name="sub"/>
        
        </form>
        <br>
         
         <?
        
        
    }else{
        
        
        
        ?>
        
          <input type="hidden" name="ip"
value="<?php echo $_POST['ip'];?>"/>
<input type="hidden" name="username" value="<?php echo $_POST['username'];?>"/>
<input type="hidden" name="password" value="<?php echo $_POST['password'];?>"/>

<input type="hidden" name="password" value="<?php echo $_POST['password'];?>"/>


<input type="hidden" name="test" value="einable"/>

<input type="hidden" name="card" value="<?php echo $card ;?>"/>
 <input class="edit" onclick="return getConfirmation();" type="submit" value="تفعيل" name="sub"/>
        
        </form>
        <br>
        <?
    }
    
}
      
      
      
  }
  
  
  
  ?>
  
 
        
   <form action="edit1.php" method="POST">
        
  
  <input type="hidden" name="ip"
value="<?php echo $_POST['ip'];?>"/>
<input type="hidden" name="username" value="<?php echo $_POST['username'];?>"/>
<input type="hidden" name="password" value="<?php echo $_POST['password'];?>"/>

<input type="hidden" name="password" value="<?php echo $_POST['password'];?>"/>



<input type="hidden" name="test" value="reset"/>

<input type="hidden" name="card" value="<?php echo $card ;?>"/>
 <input class="edit" onclick="return getConfirmation();" type="submit" value="تصفير العدادات" name="sub"/>
        
        </form>
        <br>
        

   <form action="edit1.php" method="POST">
        
  
  <input type="hidden" name="ip"
value="<?php echo $_POST['ip'];?>"/>
<input type="hidden" name="username" value="<?php echo $_POST['username'];?>"/>
<input type="hidden" name="password" value="<?php echo $_POST['password'];?>"/>

<input type="hidden" name="password" value="<?php echo $_POST['password'];?>"/>


<input type="hidden" name="test" value="remove"/>


<input type="hidden" name="card" value="<?php echo $card ;?>"/>
 <input class="edit" onclick="return getConfirmation();" type="submit" value="حذف" name="sub"/>
        
        </form>
        <br>

</fieldset>

<script>
function getConfirmation(){
    
    var A=confirm("هل انت متأكد من تنفيذ العمليه ؟");
    
if(A==true)
    {
        
        return true;
    }else{
        
        return false;
    }
}

    
</script>
</body>



</html>