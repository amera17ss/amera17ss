<?php

@$ip=$_POST['ip'];
@$username=$_POST['username'];
@$password=$_POST['password'];




require_once('api.php');
$API = new RouterosAPI();
@$API->connect($ip,$username,$password) or die('

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
        		<meta charset="utf-8">
<meta http-equiv="refresh" content="3;url=index.php" />
    <meta keywords="htmls, learn, teach"/>

    <link rel="stylesheet" type="text/css" href="style.css">
  
<link rel="icon" href="um.s" />
    <title>فشل في الاصال</title>
  
</head>
<body>
<hr>
<center>
<img class="logo" src="logo.s" width="100%">
<hr>
    
</center>

<center>
<fieldset>
<br><br>
فشل بالاتصال
<-_->?
<br>
<br>
يرجى التأكد من صحة البيانات
، او التأكد من اتصالك بالشبكه
<br>
<br>
</fieldset>



</center>






</body>



</html>


' );
    //echo " <br/>concted<br/>";
    
    
    
    $active=$API->comm("/ip/hotspot/active/print",array( ));
    $act=0;
 $getresource = $API->comm("/system/resource/print");
 //echo "<pre>";
 //print_r( $getresource);

?>


<!DOCTYPE html>
<html>
<head>
    


  
    
<meta name="viewport" content="width=device-width, initial-scale=1.0">
        		<meta charset="utf-8">
		
    <meta keywords="htmls, learn, teach"/>

    <link rel="stylesheet" type="text/css" href="style.css">
  
<link rel="icon" href="icon.s" />
    <title>الصفحة الرئيسية</title>
  
</head>
<body>

<hr>
<center>
<img class="logo" src="logo.s" width="100%">
<hr>
    
</center>

<center>
<fieldset>
    عدد المتصلين : 
    
    <?php   echo count($active);?>
         
   - CPU  :  <?php  echo $getresource[0]['cpu-load'];?>
    %
    
    <br>
    <br>

 <?php  echo $getresource[0]['uptime'];?>
:  وقت التشغيل 
    <hr>
   
   
    
</div>


<div class="form" >
  <form class="forme" action="usermanager.php" method="POST">
      
      
       <input type="hidden" name="ip"
value="<?php echo $_POST['ip'];?>"/>
<input type="hidden" name="username" value="<?php echo $_POST['username'];?>"/>
<input type="hidden" name="password" value="<?php echo $_POST['password'];?>"/>
      <img class="img"src="cards.s"><br>
      <input class="submit" type="submit"value="كروت يوزرمانجر">
      
      
      
  </form>

    
    
 
  
  <form   class="forme" action="setcard.php" method="POST">
      
      
      <input type="hidden" name="ip"
value="<?php echo $_POST['ip'];?>"/>
<input type="hidden" name="username" value="<?php echo $_POST['username'];?>"/>
<input type="hidden" name="password" value="<?php echo $_POST['password'];?>"/>
      <img class="img" src="card.s"><br>
      <input class="submit" type="submit"value="طباعة كروت">
      
      
      
  </form>
  
    
</div>

   
   
<div class="form" >
  <form class="forme" action="dateset.php" method="POST">
      
      
       <input type="hidden" name="ip"
value="<?php echo $_POST['ip'];?>"/>
<input type="hidden" name="username" value="<?php echo $_POST['username'];?>"/>
<input type="hidden" name="password" value="<?php echo $_POST['password'];?>"/>
      <img class="img"src="price.s"><br>
      <input class="submit" type="submit"value="المبيعات">
      
      
      
  </form>

      <form   class="forme" action="profile.php" method="POST">
      
      
      <input type="hidden" name="ip"
value="<?php echo $_POST['ip'];?>"/>
<input type="hidden" name="username" value="<?php echo $_POST['username'];?>"/>
<input type="hidden" name="password" value="<?php echo $_POST['password'];?>"/>
      <img class="img" src="profile.s"><br>
      <input class="submit" 
     
      type="submit"value="الباقات">
      
      
      
  </form>
    
    
    
</div>

<div class="form" >
  <form   class="forme"  action="users.php" method="POST">
      
      
      <input type="hidden" name="ip"
value="<?php echo $_POST['ip'];?>"/>
<input type="hidden" name="username" value="<?php echo $_POST['username'];?>"/>
<input type="hidden" name="password" value="<?php echo $_POST['password'];?>"/>
      <img class="img" src="users.s"><br>
      <input class="submit" type="submit"value="المستخدمين">
      
      
      
  </form>
  <form  class="forme"  action="backup.php" method="POST">
      
      
      <input type="hidden" name="ip"
value="<?php echo $_POST['ip'];?>"/>
<input type="hidden" name="username" value="<?php echo $_POST['username'];?>"/>
<input type="hidden" name="password" value="<?php echo $_POST['password'];?>"/>
      <img class="img" src="backup.s"><br>
      <input class="submit" type="submit"value="نسخه احتياطيه">
      
      
      
  </form>
    
    
    
    
</div>


<div class="form" >
  <form class="forme" action="help.php" method="POST">
      
      
       <input type="hidden" name="ip"
value="<?php echo $_POST['ip'];?>"/>
<input type="hidden" name="username" value="<?php echo $_POST['username'];?>"/>
<input type="hidden" name="password" value="<?php echo $_POST['password'];?>"/>
      <img class="img"src="help.s"><br>
      <input class="submit" type="submit"value="من انا">
      
      
      
  </form>
  <form   class="forme" action="delet.php" method="POST">
      
      
      <input type="hidden" name="ip"
value="<?php echo $_POST['ip'];?>"/>
<input type="hidden" name="username" value="<?php echo $_POST['username'];?>"/>
<input type="hidden" name="password" value="<?php echo $_POST['password'];?>"/>
      <img class="img" src="delet.s"><br>
      <input class="submit" 

      type="submit"value="الكروت المنتهيه">
      
      
      
  </form>
    
    
    

</fieldset>





</center>






</body>



</html>
