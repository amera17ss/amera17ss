<?php

@$ip=$_POST['ip'];
@$username=$_POST['username'];
@$password=$_POST['password'];




require_once('api.php');
$API = new RouterosAPI();
@$API->connect($ip,$username,$password) or die("disconcted");
    //echo " <br/>concted<br/>";
    
    
    
    $profile=$API->comm("/tool/user-manager/profile/print",array( ));
  //  echo "<pre>";
   // print_r($profile);

?>

<?php
if(isset($_POST['up']))
{

@move_uploaded_file($_FILES['file']['tmp_name'],"img/100.png");
//echo print_r($imge);

}

?>


<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
        		<meta charset="utf-8">
		
    <meta keywords="htmls, learn, teach"/>

    <link rel="stylesheet" type="text/css" href="style.css">
  
<link rel="icon" href="icon.icon" />
    <title>صفحة طباعة الكروت</title>
  
</head>
<body dir="rtl">
    

<hr>
<img class="logo" src="logo.s" width="100%">
<hr>
<center>
<fieldset>

    <hr>
    <form action="print.php" method="POST">
        
  
      اختار الباقه : 
        
        <select name="profile">
            
           <?php
    for($i=0;$i<count($profile);$i++)
           {
               
echo "<option value='".$profile[$i]['name']."'>".$profile[$i]['name']."</option>";
           }
           
           
           ?> 
        
            
            
        </select>
     اختار طول الكرت : 
        
 <select name="long">
    <option value='3'>9</option>
 <option value='4'>8</option>
 <option value='5'>7</option>
 <option value='6'>6</option>
            
            
            
        </select>
        <br>
        <br>
        بداية 
 <input class="start" type="number" name="start"/>
 نهاية
 <input class="start" type="number" name="end"/>
 العدد
<input class="start" type="number" name="numb"value="0"/>

 <br>
 <br>
 ربط الكرت مع اول مستخدم :
 <select name="accept">
     <option value="yes">نعم</option>
    <option value="no">لا</option>
 </select>
<br>
 
 <br>

فوق تحت :
<input class="start" type="number" name="up1" value="28"/>
يمين يسار :
<input class="start" type="number" name="left"value="98"/><br><br>
عرض الخط : 
<input class="start" type="number" name="size"value="8"/>

       <input type="hidden" name="ip"
value="<?php echo $_POST['ip'];?>"/>
<input type="hidden" name="username" value="<?php echo $_POST['username'];?>"/>
<input type="hidden" name="password" value="<?php echo $_POST['password'];?>"/>
<br><br>

    
 <input onclick="return getConfirmation();"   type="submit" value="طباعة"class="submit"/>
    </form>


</fieldset>
<br>
<fieldset>
    
    
<form action="setcard.php" method="POST" enctype="multipart/form-data">

       <input type="hidden" name="ip"
value="<?php echo $_POST['ip'];?>"/>
<input type="hidden" name="username" value="<?php echo $_POST['username'];?>"/>
<input type="hidden" name="password" value="<?php echo $_POST['password'];?>"/>
 <input class="file" type="file" name="file" accept="image/*"/>
 
 <input class="up" type="submit" name="up" value="رفع الصوره"/>
    
    <br><br>
    
</form>
<form action="test.php" method="POST">
    
       <input type="hidden" name="long"
value="5"/>

        بداية 
 <input class="start" type="number" name="start"/>
 نهاية
 <input class="start" type="number" name="end"/>
 العدد
<input class="start" type="number" name="numb"value="36"/><br><br>
فوق تحت :
<input class="start" type="number" name="up1" value="28"/>
يمين يسار :
<input class="start" type="number" name="left"value="98"/><br><br>
عرض الخط : 
<input class="start" type="number" name="size"value="8"/>
    <br><br>
  <input class="submit" type="submit" value=" معاينه" name="sub"/>
    
    
</form>

    
</fieldset>
<script>
function getConfirmation(){
    
    var A=confirm("هل انت متأكد من طباعة الكروت ؟");
    
if(A==true)
    {
        
        return true;
    }else{
        
        return false;
    }
}

    
</script>


</body>



</html>