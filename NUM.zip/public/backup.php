<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
        	
    <meta keywords="htmls, learn, teach"/>

    <link rel="stylesheet" type="text/css" href="style.css">
  
<link rel="icon" href="icon.s" />
    <title>نسخه احتياطيه</title>
  
</head>
<body>
<hr>
<center>
<img class="logo" src="logo.s" width="100%">
<hr>
    
</center>

<center>
<fieldset>
<?php
@$ip=$_POST['ip'];
@$username=$_POST['username'];
@$password=$_POST['password'];
require_once('api.php');
$API= new RouterosAPI();
@$API->connect($ip,$username,$password) or die("discnected");
$date=$API->comm("/system/clock/print",array());

$date1=$date[0]['date'];
$name="nu-manager-" . $date1[0].$date1[1].$date1[2]."-".$date1[4].$date1[5]."-".$date1[7].$date1[8].$date1[9].$date1[10];
$test=0;
$name1="";
@$name1=$_POST['name'];
@$test=$_POST['test'];
if(@$test==1)
{


$backup=$API->comm("/tool/user-manager/database/save",array(
    "name"=>$name
    
   ));
  
} if($test==2)
{
   $remove=$API->comm('/file/remove',array(
       
       "numbers"=>$name1
       ));
    
    
    
}
$file=$API->comm("/file/print",array());
//echo "<pre>";
//print_r($remove);
//echo $name1;

?>

<form action="backup.php" method="POST">
    
    
       <input type="hidden" name="ip"
value="<?php echo $_POST['ip'];?>"/>
<input type="hidden" name="username" value="<?php echo $_POST['username'];?>"/>
<input type="hidden" name="password" value="<?php echo $_POST['password'];?>"/>

<input type="hidden" name="test" value="1"/>
      <img class="img"src="backup.s"><br>
      <input class="submit" type="submit"value="نسخه احتياطيه لليوزر مانجر">
      
      
    <br><br>
    
</form>
<!--

<form action="backup.php" method="POST">
    
    
       <input type="hidden" name="ip"
value="<?php //echo $_POST['ip'];?>"/>
<input type="hidden" name="username" value="<?php //echo $_POST['username'];?>"/>
<input type="hidden" name="password" value="<?php// echo $_POST['password'];?>"/>


      
      <input class="submit" type="submit"value="سكربت انشاء نسخه احتياطيه تلقائي">
      
      
    <br><br>
    
</form>
-->

<?




echo "<table>";
 echo "<tr class='r'>";
        echo "<td>اسم النسخه";

        echo "</td>";
        
echo "<td>حذف";
    
        echo "</td>";
        
        echo "</tr>";
        

for($i=0;$i<count($file);$i++){
    
    if($file[$i]['type']=="userman backup")
    {
        ?>
        <tr class='r'>
            <td>
                
                <?  echo $file[$i]['name'] ; ?>
                
            </td>
            <td>
<form action="backup.php" method="POST">
    
       <input type="hidden" name="ip"
value="<?php echo $_POST['ip'];?>"/>
<input type="hidden" name="username" value="<?php echo $_POST['username'];?>"/>
<input type="hidden" name="password" value="<?php echo $_POST['password'];?>"/>

    
      <input type="hidden" name="test"
value="<? echo '2';?>"/>


      <input type="hidden" name="name"
value="    <?  echo $file[$i]['name'] ; ?>"/>
<img src='delet.s' style='
        width:30px;
        height:30px;
        
        '/>
                    <br>
            <input class="delet" type="submit" value="حذف"/>

    
    
</form>
  
                
            </td>
            
            
            
            
        </tr>
        
        <?
    
    }
    
}

echo "</table>";
?>
</fieldset>



</center>






</body>



</html>
