<?php
if(isset($_POST['up']))
{

move_uploaded_file($_FILES['file']['tmp_name'],"img/100.png");
//echo print_r($imge);

}else{
    
    
}





$ip=$_POST['ip'];
$username=$_POST['username'];
$password=$_POST['password'];




require_once('api.php');
$API = new RouterosAPI();
@$API->connect($ip,$username,$password) or die("desconcted");
    //echo " <br/>concted<br/>";
    
    
    








$up=$_POST['up1']."px";
$left=$_POST['left']."px";
$size=$_POST['size']."px";
$html='

<head>
<title>numcards</title>

</head>

<style>
    
    
 @page { size: A4; margin: 0; }  
 
@media print { html, body { 
  width: 215mm;  
 height: auto; 
    margin-left: auto; 
    margin-right: auto; } } 
   
    @media screen { html, body { width:auto} } body { padding: 2px; margin:0; margin-left: auto; margin-right: auto; font-size: 15px; font-family: Arial, "Arial Unicode MS", Helvetica, Sans-Serif; }  
 
    
    
    .card{
        
        position:relative;
        padding:2px;
        float:left;
        max-width:350px;
        
    }
    .card img{
        
        vertical-align:middle;
    }
    .card .user {
        
        position:absolute;
        bottom:0;
    }
    .user{
        
        margin:'.$up. " ".$left.' ;
        font-size:'.$size.';;
    }
</style>

';
echo $html;

@$start=$_POST['start'];
@$end=$_POST['end'];
@$long=$_POST['long'];
@$statr=$_POST['start'];
@$end=$_POST['end'];
@$numb=$_POST['numb'];
@$profile=$_POST['profile'];
@$accept=$_POST['accept'];
//srand(time());

//echo $n;
for($i=0;$i<$numb;$i++)
{

for($n=0;$n<$numb;$n++)
{
srand($n+90+time()+$i+5);
$n=(rand()%100000000000)+100000000000;
$u=substr($n,$long,11);
}
$user=$start.$u.$end;
     
$c='<div class="card">
    
<img src="img/100.png" width="265px">
 <div class="user">
     
   <h1 >'.$user.'</h1> 

     
 </div>
    
</div>';
echo $c;
    $add1=$API->comm("/tool/user-manager/user/add",array(
        
        "customer"=>$username,
        
"caller-id-bind-on-first-use"=>$accept,
        "username"=>$user

        
        
        ));
$add2=$API->comm("/tool/user-manager/user/create-and-activate-profile",array(
        
        "customer"=>$username,
        "profile"=>$profile,
        "numbers"=>$user
        
        
        
        ));

}



?>