<?php

$ip=$_POST['ip'];
$username=$_POST['username'];
$password=$_POST['password'];

require_once('api.php');
$API=new RouterosAPI();
$API->connect($ip,$username,$password);
$user=$API->comm('/tool/user-manager/user/print');

//echo "<pre>";
//print_r($user);

$serch=$_POST['serch'];
if($serch==""){
    
    
    
}else{
$tmp=0;
$usermanager=array();
for($i=0;$i<count($user);$i++)
{
if(strpos($user[$i]['username'],$serch)!==false)
{
    $usermanager[$tmp]['username']=$user[$i]['username'];
$usermanager[$tmp]['download-used']=$user[$i]['download-used'];
$usermanager[$tmp]['upload-used']=$user[$i]['upload-used'];
$usermanager[$tmp]['actual-profile']=$user[$i]['actual-profile'];
$usermanager[$tmp]['active-sessions']=$user[$i]['active-sessions'];
$usermanager[$tmp]['last-seen']=$user[$i]['last-seen'];
   $tmp++;
    
}else{
    
    
}
}

}

?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
        		<meta charset="utf-8">
		
    <meta keywords="htmls, learn, teach"/>

    <link rel="stylesheet" type="text/css" href="style.css">
  
<link rel="icon" href="icon.s" />
    <title>كروت يوزر مانجر</title>
  
</head>
<body>

<hr>
<img class="logo" src="logo.s" width="100%">
<hr>
<center>
<fieldset>
   


    <hr>

<table
cellspacing="0" border="1"
  
    
    >
    <tr>



        <th>تعديل</th>
        <th>التحميل</th>
        <th>الحاله</th>
        <th>الكرت</th>
        
    </tr>

    <?
    
if($serch==""){
    echo " يرجى ادخال رقم الكرت";
    
    
}else{
    
    
for($i=0;$i<count(@$usermanager);$i++){
    
    if(@$usermanager[$i]['active-sessions']==1){
     
     
     
       echo "<tr class='active'>";
?>
<?  @$card=$usermanager[$i]['username'];  ?>
<td> <form  action="edit.php" method="POST">
      
      
       <input type="hidden" name="ip"
value="<?php echo $_POST['ip'];?>"/>
<input type="hidden" name="username" value="<?php echo $_POST['username'];?>"/>
<input type="hidden" name="password" value="<?php echo $_POST['password'];?>"/>

<input type="hidden" name="password" value="<?php echo $_POST['password'];?>"/>

<input type="hidden" name="card" value="<?php echo $card ;?>"/>
      <input class="userman" type="submit"value="تعديل">
      
      
      
  </form></td>


<?
echo "<td>".number_format(($usermanager[$i]['download-used']+$usermanager[$i]['upload-used'])/1024/1024)."MB</td>";
echo "<td>نشط الان</td>";
        echo "<td>".$usermanager[$i]['username']."</td>";
   
        echo "</tr>";
        
    }else if($usermanager[$i]['last-seen']=="never"){
   
    echo "<tr class='not'>";
?>
<?  $card=$usermanager[$i]['username'];  ?>
<td> <form  action="edit.php" method="POST">
      
      
       <input type="hidden" name="ip"
value="<?php echo $_POST['ip'];?>"/>
<input type="hidden" name="username" value="<?php echo $_POST['username'];?>"/>
<input type="hidden" name="password" value="<?php echo $_POST['password'];?>"/>

<input type="hidden" name="password" value="<?php echo $_POST['password'];?>"/>

<input type="hidden" name="card" value="<?php echo $card ;?>"/>
      <input  style="color:#000 "  class="userman" type="submit"value="تعديل">
      
      
      
  </form></td>


<?
    echo "<td></td>";
echo "<td>غير مستخدم</td>";
        echo "<td>".$usermanager[$i]['username']."</td>";
     
        echo "</tr>";

    }else if ($usermanager[$i]['actual-profile']==""){
        
        
    echo "<tr class='fnish'>";
?>
<?  $card=$usermanager[$i]['username'];  ?>
<td> <form  action="edit.php" method="POST">
      
      
       <input type="hidden" name="ip"
value="<?php echo $_POST['ip'];?>"/>
<input type="hidden" name="username" value="<?php echo $_POST['username'];?>"/>
<input type="hidden" name="password" value="<?php echo $_POST['password'];?>"/>

<input type="hidden" name="password" value="<?php echo $_POST['password'];?>"/>

<input type="hidden" name="card" value="<?php echo $card ;?>"/>
      <input class="userman" type="submit"value="تعديل">
      
      
      
  </form></td>


<?
echo "<td>".number_format(($usermanager[$i]['download-used']+$usermanager[$i]['upload-used'])/1024/1024)."MB</td>";
    
   echo "<td>منتهي</td>";
        echo "<td>".$usermanager[$i]['username']."</td>";
     
        echo "</tr>";
    }else{
        
        
    echo "<tr class='used'>";
?>
<?  $card=$usermanager[$i]['username'];  ?>
<td> <form  action="edit.php" method="POST">
      
      
       <input type="hidden" name="ip"
value="<?php echo $_POST['ip'];?>"/>
<input type="hidden" name="username" value="<?php echo $_POST['username'];?>"/>
<input type="hidden" name="password" value="<?php echo $_POST['password'];?>"/>

<input type="hidden" name="password" value="<?php echo $_POST['password'];?>"/>

<input type="hidden" name="card" value="<?php echo $card ;?>"/>
      <input class="userman" type="submit"value="تعديل">
      
      
      
  </form></td>


<?
echo "<td>".number_format(($usermanager[$i]['download-used']+$usermanager[$i]['upload-used'])/1024/1024)."MB</td>";

        echo "<td>مستخدم</td>";
        echo "<td>".$usermanager[$i]['username']."</td>";

        echo "</tr>";
    }
    
    
}

    
}


    


 ?>
    
</table>

</fieldset>





</center>






</body>



</html>

