<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
        		<meta charset="utf-8">
		
    <meta keywords="htmls, learn, teach"/>

    <link rel="stylesheet" type="text/css" href="style.css">
  
<link rel="icon" href="icon.icon" />
    <title>برنامج ادارة الشبكة</title>
  
</head>
<body>
<center>
    
<hr>
<img class="logo" src="logo.s" width="100%">
<hr>
     
    
</center>

<center>
<fieldset>
يرجى ادخال البيانات الخاصه بالشبكة
    <hr>
<img class="img"src="user.s"/>
<div class="login">
    
    <form name="form1" action="home.php"method="POST">
        
<input class="input"type="text" name="ip" value=""
placeholder="ip"

/>
<br><input class="input" type="text" name="username" value=""

placeholder="اسم المستخدم"
					

/><br>
<input class="input" type="password" name="password" value=""
placeholder="كلمة السر"
/><br>

<input  class="submit" class="submit"  type="submit" onclick="return err();" name="sup" value="دخول"/>
        
        
    </form>
        
        
    
    
</div>

</fieldset>





</center>




<script>
    
 function err(){
     
 if(form1.ip.value==""){
     
     alert("لا يمكن ترك العنوان ال ip فارغ !");
     return false;
     
     
 }
if(form1.username.value==""){
     
     alert("لا يمكن ترك اسم المستخدم فارغ !");
     return false;
     
     
 }

 }   
    
    
</script>



</body>



</html>
