<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
        		<meta charset="utf-8">
		
    <meta keywords="htmls, learn, teach"/>

    <link rel="stylesheet" type="text/css" href="style.css">
  
<link rel="icon" href="icon.s" />
    <title>من انا</title>
  
</head>
<body>

<hr>

<img class="logo" src="logo.s" width="100%">
<hr>
<center>
<h1 class="h1">المهندس : نجيب مراد </h1>
<hr>
<fieldset>
    <p style="font-size:15px">
مرحباً بكم في برنامج ادارة الشبكه <br>
ونشكركم لاستخدامكم لبرنامجنا المتواضع والبسيط<br><br>
لاي خلل او دعم فني يرجى التواصل بنا
</p>


<div >
<a class="s"href="sms:+967772339262">sms</a>

    
    
<a class="w"href="https://api.whatsapp.com/send?phone=+967772339262&text">واتساب</a>




<a class="y"href="https://youtube.com/c/MORUD262">يوتيوب</a>

    
</div>
</fieldset>





</center>






</body>



</html>