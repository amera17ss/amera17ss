<?php
$ip=$_REQUEST['ip'];
$username=$_REQUEST['username'];
$password=$_REQUEST['password'];
//echo $ip;



require_once('api.php');
$API = new RouterosAPI();
@$API->connect($ip,$username,$password) or die("diconcted");
    //echo " <br/>concted<br/>";
    
    
    
    $date=$API->comm("/system/clock/print",array(
        ));
        //echo "<pre>";
      //  print_r($date)
$years=substr($date[0]['date'],7,10);
      
        
        ?>



<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
        		<meta charset="utf-8">
		
    <meta keywords="htmls, learn, teach"/>

    <link rel="stylesheet" type="text/css" href="style.css">
  
<link rel="icon" href="icon.s" />
    <title>المبيعات</title>
  
</head>
<body dir="rtl">

<hr>
<img class="logo" src="logo.s" width="100%">
<hr>
<center>
<fieldset>
    <p font-size="">
    *
    يرجى ادخال التاريخ بشكل صحيح لكي تظهر معك كل البيانات<br> 
    ! 
    حذف الكروت المنتهيه يؤثر على صحة البيانات
   </p> <hr>
    <div>
    <form action="selling.php" method="POST">
<input type="hidden" name="tmp"
value="t"/>
<input type="hidden" name="ip"
value="<?php echo $_POST['ip'];?>"/>
<input type="hidden" name="username" value="<?php echo $_POST['username'];?>"/>
<input type="hidden" name="password" value="<?php echo $_POST['password'];?>"/>
من
<select name="day1">

    <?php
    for($i=1;$i<=31;$i++)
    {
        echo "<option value='".$i."'>".$i."</option>";
        
    }
    
    
    ?>
    <br>
</select>
الى
<select name="day2">
    
    <?php
    for($i=1;$i<=31;$i++)
    {
        echo "<option value='".$i."'>".$i."</option>";
        
    }
    
    
    ?>
</select>
في شهر
<select name="month">
    <option value='jan'>1</option>
    <option value="feb">2</option>
    <option value="mar">3</option>
    <option value="apr">4</option>
    <option value="may">5</option>
    <option value="jun">6</option>
    <option value="jul">7</option>
    <option value="aug">8</option>
    <option value="sep">9</option>
    <option value="oct">10</option>
    <option value="nov">11</option>
    <option value="des">12</option>
    
    
</select>
<br><br>
في سنة: 
<select name="years">
    
    <option value="<?php echo $years; ?>"><?php echo $years; ?></option>
    <?php
    for($i=2020;$i<=2030;$i++)
    {
        echo "<option value='".$i."'>".$i."</option>";
        
    }
    
    
    ?>
</select>
<br>
<br>
<input class="submit" type="submit" name="sup" value="عرض"/>
        
        
    </form>
    <br>
    
    <form action="selling.php" method="POST">
<input type="hidden" name="tmp"
value="f"/>
<input type="hidden" name="ip"
value="<?php echo $_POST['ip'];?>"/>
<input type="hidden" name="username" value="<?php echo $_POST['username'];?>"/>
<input type="hidden" name="password" value="<?php echo $_POST['password'];?>"/>
<input type="hidden" name="date"
value="<?php echo $date[0]['date'];?>"/>
        
<input class="submit" type="submit" name="sup" value="مبيعات اليوم"/>
        
        
    </form>
        </div>


</fieldset>





</center>






</body>



</html>
