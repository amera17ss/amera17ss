<?php

$ip=$_POST['ip'];
$username=$_POST['username'];
$password=$_POST['password'];




require_once('api.php');
$API = new RouterosAPI();
@$API->connect($ip,$username,$password) or die("desconcted");
    //echo " <br/>concted<br/>";
    
    
    
    $active=$API->comm("/ip/hotspot/active/print",array( ));
    
$users=$API->comm("/ip/hotspot/active/print",array( ));
    $act=0;
 $getresource = $API->comm("/system/resource/print");
// echo "<pre>";
// print_r( $users);

?>



<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
        		<meta charset="utf-8">
		
    <meta keywords="htmls, learn, teach"/>

    <link rel="stylesheet" type="text/css" href="style.css">
  
<link rel="icon" href="icon.s" />
    <title>صفحة المستخدمين</title>
  
</head>
<body>

<hr>
<img class="logo" src="logo.s" width="100%">
<hr>
<center>
<fieldset>
    عدد المتصلين : 
    
    <?php   echo count($active);?>
         
   - CPU  :  <?php  echo $getresource[0]['cpu-load'];?>
    %
    
    <br>
    <br>

 <?php  echo $getresource[0]['uptime'];?>
:  وقت التشغيل 
    <hr>

<table
cellspacing="0" border="1"
  
    
    >
    <tr>



        <th>التحميل</th>
        <th>MAC</th>
        <th>وقت الاتصال</th>
        <th>الكرت</th>
        
    </tr>
    <?php
    $mb=0;
    for($i=0;$i<count($users);$i++)
    {
        echo "<tr>";
$mb=($users[$i]['bytes-out']+$users[$i]['bytes-in'])/1024/1024;
echo "<td class='fo'  >".number_format($mb)." MB </td>";

echo "<td class='fo' >".$users[$i]['mac-address']."</td>";
echo "<td class='fo'  >  ".$users[$i]['uptime']." </td> ";
echo " <td  class='fo'   >".$users[$i]['user']."</td>";
echo "</tr>";
    };
    
    
    ?>
    
    
</table>

</fieldset>





</center>






</body>



</html>