<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
        		<meta charset="utf-8">
		
    <meta keywords="htmls, learn, teach"/>

    <link rel="stylesheet" type="text/css" href="style.css">
  
<link rel="icon" href="icon.s" />
    <title>اضافة باقات</title>
  
</head>
<body>

<hr>
<img class="logo" src="logo.s" width="100%">
<hr>
<center>
<fieldset>
قريباً

</fieldset>





</center>






</body>



</html>